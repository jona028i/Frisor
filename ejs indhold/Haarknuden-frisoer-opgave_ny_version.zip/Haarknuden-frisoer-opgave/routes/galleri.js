module.exports = function (app) {

    app.get('/galleri', function (req, res) {
		res.render('pages/galleri', {
            message: 'galleri',
            showLogud: req.session.userId
        });
	});

}