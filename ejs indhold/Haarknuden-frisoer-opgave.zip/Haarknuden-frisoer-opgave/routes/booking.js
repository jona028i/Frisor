module.exports = function (app) {

    app.get('/booking', function (req, res) {
        let jsonBooking = require('../data/booking.json');
        res.render('pages/booking', {
            booking: jsonBooking,
            showLogud: req.session.userId
        });
        console.log(jsonBooking);
    });

};