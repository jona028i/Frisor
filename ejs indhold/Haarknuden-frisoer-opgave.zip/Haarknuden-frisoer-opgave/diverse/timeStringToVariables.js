let time = 1845;
time = time.toString();
let hour = time.substring(0,2);
let minute = time.substring(2,4);

console.log(hour+':'+minute);