var d = '2018-02-12T13:45:00Z';
console.log(new Date(d).valueOf());