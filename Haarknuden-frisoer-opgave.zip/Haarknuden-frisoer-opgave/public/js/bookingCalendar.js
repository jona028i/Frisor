let curDate = new Date();
let calendarMonth = curDate.getMonth()+1;
let calendarYear = 2018;
let dagsdato = curDate.getDate();
let aabningstider = require('../data/aabningstider.json');

console.log(aabningstider);

let prevMonth = document.getElementById('calendarPrev');
let nextMonth = document.getElementById('calendarNext');
let bookingSUbmit = document.getElementById('bookingSUbmit');

nextMonth.addEventListener('click', function() {
    monthCounter('add');
    document.getElementById("calendar").innerHTML = ``;
    updateCalendar(calendarMonth, calendarYear);
});

prevMonth.addEventListener('click', function() {
    monthCounter('sub');
    document.getElementById("calendar").innerHTML = ``;
    updateCalendar(calendarMonth, calendarYear);
});

function vaelgDag(day) {
    dagsdato = day;
}

function monthCounter(method) {
    if(method == 'add') {
        calendarMonth++;
    } else {
        calendarMonth--; 
    }
    if(calendarMonth > 12) {
        calendarMonth = 1;
    } else if(calendarMonth < 1) {
        calendarMonth = 12;
    }
}

function convertDate(dato) {
    dato = dato.toString();
    if(dato.length > 1) {
        return dato;
    } else {
        return `0${dato}`;
    }
}

function updateCalendar(month, year) {
    let monthName = ['empty', 'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'December'];
    let date = new Date(year, month);
    let monthDays = date.getUTCDate();
    document.getElementById("calendarMonth").innerHTML = monthName[month];
    for (cDays = 1; cDays < monthDays+1; cDays++) {
        if(curDate.getMonth()+1 > month) {
            document.getElementById("calendar").innerHTML += `<li class="calendarDisabled">${cDays}</li>`;
        } else if(curDate.getMonth()+1 < month) {
            document.getElementById("calendar").innerHTML += `<li class="calendarDay" onclick="vaelgDag(${cDays})">${cDays}</li>`;
        } else {
            if(cDays < curDate.getDate()) {
                document.getElementById("calendar").innerHTML += `<li class="calendarDisabled">${cDays}</li>`;
            } else {
                if(curDate.getDate() == cDays && curDate.getMonth()+1 == month) {
                document.getElementById("calendar").innerHTML += `<li class="calendarDay calendarToday" onclick="vaelgDag(${cDays})">${cDays}</li>`;
            } else {
                document.getElementById("calendar").innerHTML += `<li class="calendarDay" onclick="vaelgDag(${cDays})">${cDays}</li>`;
            }
            }
        }
    }
}

bookingSUbmit.addEventListener('click', function() {
    let vaelgtTid = document.getElementById('vaelgtTid').value;
    let testdato = `${calendarYear.toString()}-${convertDate(calendarMonth.toString())}-${convertDate(dagsdato.toString())}T${vaelgtTid.toString()}Z`;
    let test = new Date(testdato).valueOf();
    console.log(test);
});

let aabentidtime = 10;
let aabentidminut = 0;
let lukketidtime = 18;
let lukketidminut = 0;
let lukketime = aabentidtime;
let lukkeminut = 0;
while(lukketime < lukketidtime) {
    let samlettid = convertDate(lukketime) + ':' + convertDate(lukkeminut);
    document.getElementById("vaelgtTid").innerHTML += `<option value="${samlettid}">${samlettid}</option>`;
    lukkeminut = lukkeminut + 30;
    if(lukkeminut == 60) {
        lukkeminut = 0;
        lukketime++;
    }
}

updateCalendar(calendarMonth, calendarYear);